//CS 210 Project 1
//Erik Sierra
//7/13/2023


#include <iostream>
#include <iomanip>
#include <string> //converts integer to string (limits length of characters)

std::string twoDigitString(int value) { //places leading zero if input is less than 10
    if (value < 10) {
        return "0" + std::to_string(value);
    }
    else {
        return std::to_string(value);
    }
}
void displayClocks(int hours, int minutes, int seconds) {  //displays clocks side by side with border
    std::string amPm = (hours < 12) ? "AM" : "PM";
    int militaryHours = hours;
    if (hours > 12) {  //resets 12 hour clock to 0 when 12th hour is reached
        militaryHours -= 12;
    }

    std::cout << "********************      ********************\n";
    std::cout << "* 12-Hour Clock    *      * Military Time    *\n";
    std::cout << "*   " << std::setw(2) << std::setfill('0') << militaryHours << " : " << std::setw(2) << minutes << " : " << std::setw(2) << seconds << " " << amPm << " *      *   ";
    std::cout << std::setw(2) << hours << " : " << std::setw(2) << minutes << " : " << std::setw(2) << seconds << "       *\n";
    std::cout << "********************      ********************\n";
}

void addOneHour(int& hours) { //adds one hour to time clock. Prevnts going over 24 hours
    hours = (hours + 1) % 24;
}

void addOneMinute(int& minutes) {  //adds one minute to time clock. Prevnts going over 60 minutes
    minutes = (minutes + 1) % 60;
}

void addOneSecond(int& seconds) { //adds one seconds to time clock. Prevnts going over 60 seconds
    seconds = (seconds + 1) % 60;
}

int performMenuChoice(int& hours, int& minutes, int& seconds) {  //Menu prompts user to add respective amount of time based on number chosen in list
    int choice;
    std::cout << "Enter your choice: ";
    std::cin >> choice;

    switch (choice) {
    case 1:
        addOneHour(hours);
        break;
    case 2:
        addOneMinute(minutes);
        break;
    case 3:
        addOneSecond(seconds);
        break;
    case 4:
        return 4; // Exit program
    default:
        std::cout << "Invalid choice. Please try again.\n";
        break;
    }

    return 0; // Continue program
}
void getInput(int& hours, int& minutes, int& seconds) {  //Prompts user to input initial time. 
    std::cout << "Enter hours: ";
    std::string hoursInput;
    std::cin >> hoursInput;

    if (hoursInput.length() <= 2) {  //adds leading 0 if input is between 0 and 9
        hours = std::stoi(hoursInput);
    }
    else {
        hours = std::stoi(hoursInput.substr(0, 2));
    }

    if (hours > 24) {  //Notifies user the clock cannot accept hours greater than 24 
        std::cout << "Invalid input. Hours cannot be greater than 24. Setting hours to 24.\n";
        hours = 24;
    }

    std::cout << "Enter minutes: ";
    std::string minutesInput;
    std::cin >> minutesInput;

    if (minutesInput.length() <= 2) {  //adds leading 0 if input is between 0 and 9
        minutes = std::stoi(minutesInput);
    }
    else {
        minutes = std::stoi(minutesInput.substr(0, 2));
    }

    if (minutes > 59) {  //Notifies user the clock cannot accept minutes greater than 60 
        std::cout << "Invalid input. Minutes cannot be greater than 59. Setting minutes to 59.\n";
        minutes = 59;
    }

    std::cout << "Enter seconds: ";  
    std::string secondsInput;
    std::cin >> secondsInput;

    if (secondsInput.length() <= 2) {  //adds leading 0 if input is between 0 and 9
        seconds = std::stoi(secondsInput);
    }
    else {
        seconds = std::stoi(secondsInput.substr(0, 2));
    }

    if (seconds > 59) {  //Notifies user the clock cannot accept seconds greater than 60 
        std::cout << "Invalid input. Seconds cannot be greater than 59. Setting seconds to 59.\n";
        seconds = 59;
    }
}


int main() {  //calls previously defined functions
    int hours, minutes, seconds;

    getInput(hours, minutes, seconds);

    bool exitProgram = false;  //sets boolean to false

    while (!exitProgram) {  //while loop will continue to run as long as boolean is false
        displayClocks(hours, minutes, seconds);

        std::cout << "********************\n";
        std::cout << "1. Add One Hour    *\n";
        std::cout << "2. Add One Minute  *\n";
        std::cout << "3. Add One Second  *\n";
        std::cout << "4. Exit Program    *\n";
        std::cout << "********************\n";

        int menuResult = performMenuChoice(hours, minutes, seconds);
        if (menuResult == 4) {
            exitProgram = true;  //sets boolean to true, causing while loop to stop and program to exit
        }

        std::cout << std::endl;
    }

    return 0;
}
