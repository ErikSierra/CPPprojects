#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

class itemTracker {   //Tracks item frequencies
public:
    map<string, int> items;

    void readInputFile(const string& fileName) {
        ifstream inputFile(fileName);
        if (!inputFile.is_open()) {
            cerr << "Error opening input file." << endl;
            exit(1);
        }

        string item;
        while (inputFile >> item) {
            items[item]++;
        }
        inputFile.close();
    }

    void writeFrequencyFile(const string& fileName) {   //Opens and reads txt file. Displays error if failed
        ofstream outputFile(fileName);
        if (!outputFile.is_open()) {
            cerr << "Error opening output file." << endl;
            exit(1);
        }

        for (const auto& entry : items) {
            outputFile << entry.first << " " << entry.second << endl;
        }
        outputFile.close();
    }
};

int main() {   //displays menu for user input
    itemTracker tracker;
    tracker.readInputFile("CS210_Project_Three_Input_File.txt");
    tracker.writeFrequencyFile("frequency.dat");

    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Look up item frequency\n";
        cout << "2. Print frequency list\n";
        cout << "3. Print frequency histogram\n";
        cout << "4. Exit\n";

        int choice;
        cout << "Select an option: ";
        cin >> choice;

        if (choice == 1) {
            string item;
            cout << "Enter the item to look up: ";
            cin >> item;

            if (tracker.items.find(item) != tracker.items.end()) {
                int frequency = tracker.items[item];
                cout << "The frequency of " << item << " is " << frequency << endl;
            }
            else {
                cout << "Item not found." << endl;
            }
        }
        else if (choice == 2) {
            for (const auto& entry : tracker.items) {
                cout << entry.first << " " << entry.second << endl;
            }
        }
        else if (choice == 3) {
            for (const auto& entry : tracker.items) {
                cout << entry.first << " ";
                for (int i = 0; i < entry.second; ++i) {
                    cout << "*";
                }
                cout << endl;
            }
        }
        else if (choice == 4) {
            break;
        }
        else {
            cout << "Invalid option. Please select a valid option." << endl;
        }
    }

    return 0;
}
