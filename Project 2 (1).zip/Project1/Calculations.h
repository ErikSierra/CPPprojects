//CS 210 Project 2 
//Erik Sierra
//7/26/2023


#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main() {
    // Prompt user for inputs
    double initialInvestment, monthlyDeposit, annualInterest;
    int numYears;

    cout << "Initial Investment Amount: $";
    cin >> initialInvestment;

    cout << "Monthly Deposit: $";
    cin >> monthlyDeposit;

    cout << "Annual Interest (%): ";
    cin >> annualInterest;

    cout << "Number of Years: ";
    cin >> numYears;

    // Calculate and display Chart 1 (without additional monthly deposits)
    double balance1 = initialInvestment;
    double annualInterestRate = annualInterest / 100.0;

    cout << "\nChart 1: Without Additional Monthly Deposits\n";
    cout << "-------------------------------------------\n";
    cout << setw(5) << "Year" << setw(20) << "Year-End Balance" << setw(20) << "Year-End Interest" << endl;
    cout << "-------------------------------------------\n";

    double totalInterest1 = 0.0;

    for (int year = 1; year <= numYears; ++year) {
        double interest = balance1 * annualInterestRate;
        totalInterest1 += interest;
        balance1 += interest;

        cout << setw(5) << year << fixed << setprecision(2) << setw(20) << balance1 << setw(20) << interest << endl;
    }


    // Calculate and display Chart 2 (with additional monthly deposits)
    double balance2 = initialInvestment;

    cout << "\nChart 2: With Additional Monthly Deposits\n";
    cout << "----------------------------------------\n";
    cout << setw(5) << "Year" << setw(20) << "Year-End Balance" << setw(20) << "Year-End Interest" << endl;
    cout << "----------------------------------------\n";

    double totalInterest2 = 0.0;

    for (int year = 1; year <= numYears; ++year) {
        double totalInterestForYear = 0.0;

        for (int month = 1; month <= 12; ++month) {
            double interest = balance2 * (annualInterestRate / 12.0);
            totalInterest2 += interest;
            totalInterestForYear += interest;
            balance2 += monthlyDeposit + interest;
        }

        cout << setw(5) << year << fixed << setprecision(2) << setw(20) << balance2 << setw(20) << totalInterestForYear << endl;
    }
    cout << "\nTotal Balance after " << numYears << " Years: $" << fixed << setprecision(2) << balance2 << endl;  //display total balance


    return 0;
}
